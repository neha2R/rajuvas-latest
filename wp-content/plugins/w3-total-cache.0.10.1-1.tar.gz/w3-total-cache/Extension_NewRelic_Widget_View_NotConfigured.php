<?php
namespace W3TC;

if ( !defined( 'W3TC' ) )
	die();

?>
<?php _e( 'You have not configured API key and Account Id.', 'w3-total-cache' )?>
