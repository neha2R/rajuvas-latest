<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit; 
}

if(!defined('HSAS_FAVURL')) define('HSAS_FAVURL', 'http://www.gopiplus.com/work/2010/07/18/horizontal-scrolling-announcement/' );