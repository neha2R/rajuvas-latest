<p>The country detection and report can be enabled with the Reports Extension.</p>

