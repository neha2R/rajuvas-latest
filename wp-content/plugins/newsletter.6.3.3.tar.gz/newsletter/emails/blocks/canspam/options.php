<?php

/* @var $fields NewsletterFields */
?>

<p>Company data can be globally set on company info panel.</p>

<?php $fields->font() ?>
<?php $fields->block_commons() ?>
