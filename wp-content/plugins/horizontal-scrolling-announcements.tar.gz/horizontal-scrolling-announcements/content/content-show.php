<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit; 
}

// Form submitted, check the data
if (isset($_POST['frm_hsas_display']) && $_POST['frm_hsas_display'] == 'yes') {
	$guid = isset($_GET['guid']) ? $_GET['guid'] : '0';
	hsas_cls_security::hsas_check_guid($guid);

	$hsas_success = '';
	$hsas_success_msg = FALSE;

	// First check if ID exist with requested ID
	$result = hsas_cls_dbquery::hsas_content_count($guid);
	if ($result != '1') {
		?><div class="error fade">
			<p><strong>
				<?php echo __( 'Oops, selected details does not exists.', 'horizontal-scrolling-announcements' ); ?>
			</strong></p>
		</div><?php
	} else {
		// Form submitted, check the action
		if (isset($_GET['ac']) && $_GET['ac'] == 'del' && isset($_GET['guid']) && $_GET['guid'] != '') {
			//	Just security thingy that wordpress offers us
			check_admin_referer('hsas_form_show');

			//	Delete selected record from the table
			hsas_cls_dbquery::hsas_content_delete($guid);

			//	Set success message
			$hsas_success_msg = TRUE;
			$hsas_success = __( 'Selected record deleted.', 'horizontal-scrolling-announcements' );
		}
	}
	
	if ($hsas_success_msg == TRUE) {
		?><div class="notice notice-success is-dismissible">
			<p><strong>
				<?php echo $hsas_success; ?>
			</strong></p>
		</div><?php
	}
}
?>

<div class="wrap">
	<h2>
		<?php echo __( 'Horizontal scrolling announcements', 'horizontal-scrolling-announcements' ); ?>  
		<a class="add-new-h2" href="<?php echo HSAS_ADMINURL; ?>?page=hsas-content&amp;ac=add"><?php echo __( 'Add New', 'horizontal-scrolling-announcements' ); ?></a>
	</h2>
	<div class="tablenav top">
	<select name="hsas_groupname" id="hsas_groupname">
	  <option value=''><?php _e('All Group', 'horizontal-scrolling-announcements'); ?></option>
	</select>
	<input id="doaction" class="button action" value="Filter" type="button"><input id="doaction" class="button action" value="Help" type="button" onclick="return _hsas_help()">
	</div>
	<div class="tool-box">
		<?php
			$myData = array();
			$myData = hsas_cls_dbquery::hsas_content_view("", 0, 1000);
		?>
		<form name="frm_hsas_display" method="post">
			<table width="100%" class="widefat" id="straymanage">
				<thead>
					<tr>
						<th scope="col"><?php echo __( 'Announcement', 'horizontal-scrolling-announcements' ); ?></th>
						<th scope="col" width="15%"><?php echo __( 'Group', 'horizontal-scrolling-announcements' ); ?></th>
						<th scope="col" width="10%"><?php echo __( 'Start', 'horizontal-scrolling-announcements' ); ?></th>
						<th scope="col" width="10%"><?php echo __( 'End', 'horizontal-scrolling-announcements' ); ?></th>
					</tr>
				</thead>
				<tfoot>
					<tr>
						<th scope="col"><?php echo __( 'Announcement', 'horizontal-scrolling-announcements' ); ?></th>
						<th scope="col"><?php echo __( 'Group', 'horizontal-scrolling-announcements' ); ?></th>
						<th scope="col"><?php echo __( 'Start', 'horizontal-scrolling-announcements' ); ?></th>
						<th scope="col"><?php echo __( 'End', 'horizontal-scrolling-announcements' ); ?></th>
					</tr>
				</tfoot>
				<tbody>
					<?php 
						$i = 0;
						$displayisthere = FALSE;
						if(count($myData) > 0) {
							$i = 1;
							foreach ($myData as $data) {
							?>
								<tr class="<?php if ($i&1) { echo'alternate'; } else { echo ''; }?>">
									<td><?php echo stripslashes($data['hsas_text']); ?>
									<div class="row-actions">
										<span class="edit">
										<a title="Edit" href="<?php echo HSAS_ADMINURL; ?>?page=hsas-content&amp;ac=edit&amp;guid=<?php echo $data['hsas_guid']; ?>"><?php _e('Edit', 'horizontal-scrolling-announcements'); ?></a> 
										</span>
										<span class="trash">
										| <a onClick="javascript:_hsas_delete('<?php echo $data['hsas_guid']; ?>')" href="javascript:void(0);"><?php _e('Delete', 'horizontal-scrolling-announcements'); ?></a>
										</span>
									</div>
									</td>
									<td><?php echo $data['hsas_group']; ?></td>
									<td><?php echo $data['hsas_datestart']; ?></td>
									<td><?php echo $data['hsas_dateend']; ?></td>
								</tr>
							<?php
								$i = $i+1;
							}
						} else {
							?><tr>
								<td colspan="4" align="center"><?php echo __( 'No records available.', 'horizontal-scrolling-announcements' ); ?></td>
							</tr><?php 
						}
					?>
				</tbody>
			</table>
			<?php wp_nonce_field('hsas_form_show'); ?>
			<input type="hidden" name="frm_hsas_display" value="yes"/>
		</form>
	</div>
	<p class="description">
		<a target="_blank" href="<?php echo HSAS_FAVURL; ?>">Click here</a> for plugin live demo<br />
		<?php _e('For more information about this plugin', 'horizontal-scrolling-announcements'); ?>
		<a target="_blank" href="<?php echo HSAS_FAVURL; ?>"><?php _e('click here', 'horizontal-scrolling-announcements'); ?></a><br />
	</p>
</div>